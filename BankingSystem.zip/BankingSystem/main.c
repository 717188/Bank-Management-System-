#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void registerUser(MYSQL *conn);
void loginUser(MYSQL *conn);
void checkAccountDetails(MYSQL *conn, int user_id);
void depositMoney(MYSQL *conn, int user_id);
void withdrawMoney(MYSQL *conn, int user_id);
double checkAccountBalance(MYSQL *conn, int user_id);

int main() {
    MYSQL *conn;

    conn = mysql_init(NULL);

    if (mysql_real_connect(conn, "localhost", "root", "Samitha@15", "bank_db", 0, NULL, 0)) {
        printf("Connected to MySQL server.\n");

        int choice;
        do {
            printf("\nMenu:\n");
            printf("1. Register\n");
            printf("2. Login\n");
            printf("3. Exit\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);

            switch (choice) {
                case 1:
                    registerUser(conn);
                    printf("Returning to menu......");
                case 2:
                    loginUser(conn);
                    printf("Returning to menu......");
                case 3:
                    printf("Exiting program.\n");
                    break;
                default:
                    printf("Invalid choice. Please enter a number between 1 and 3.\n");
                    break;
            }
        } while (choice != 3);

        mysql_close(conn);
    } else {
        fprintf(stderr, "Connection failed: %s\n", mysql_error(conn));
        return 1;
    }

    return 0;
}

void registerUser(MYSQL *conn) {
    // Prompt user for details
    char name[256];
    char address[256];
    char phone_number[16];
    char nic_number[16];
    int pin;

    printf("Enter Name: ");
    scanf("%s", name);
    printf("Enter Address: ");
    scanf("%s", address);
    printf("Enter Phone Number: ");
    scanf("%s", phone_number);
    printf("Enter NIC Number: ");
    scanf("%s", nic_number);
    printf("Enter PIN: ");
    scanf("%d", &pin);

    // Execute query to insert user details into your_table_name
    char query[256];
    sprintf(query, "INSERT INTO users (name, address, phone_number, nic_number) VALUES ('%s', '%s', '%s', '%s')",
            name, address, phone_number, nic_number);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Insertion into users failed: %s\n", mysql_error(conn));
        return;
    }

    // Get the user_id of the newly inserted row
    int user_id = mysql_insert_id(conn);

    // Execute query to insert account details into account table
    sprintf(query, "INSERT INTO account (user_id, balance, pin) VALUES (%d, 0.0, %d)", user_id, pin);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Insertion into account failed: %s\n", mysql_error(conn));
        return;
    }

    printf("User registered successfully.\n");

    printf("\nUser Details:\n");
    printf("User ID: %d, Name: %s, Address: %s, Phone Number: %s, NIC Number: %s\n", user_id, name, address, phone_number, nic_number);

    printf("\nAccount Details:\n");
    printf("Account ID: %d, User ID: %d, Balance: %.2f, PIN: %d\n", mysql_insert_id(conn), user_id, 0.0, pin);
    printf("\nPlease Notedown thease details......!!!!\n");
}

void loginUser(MYSQL *conn) {
    // Prompt user for user_id and pin
    int user_id, pin;

    printf("Enter User ID: ");
    scanf("%d", &user_id);
    printf("Enter PIN: ");
    scanf("%d", &pin);

    // Execute query to check if user_id and pin match
    char query[256];
    sprintf(query, "SELECT * FROM account WHERE user_id = %d AND pin = %d", user_id, pin);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Login query failed: %s\n", mysql_error(conn));
        return;
    }

    MYSQL_RES *result = mysql_store_result(conn);
    int num_rows = mysql_num_rows(result);

    if (num_rows == 1) {
        printf("Login successful.\n");

        int choice;
        do {
            // Display menu for logged-in users
            printf("\nLogged-In Menu:\n");
            printf("1. Check Account Details\n");
            printf("2. Deposit Money\n");
            printf("3. Withdraw Money\n");
            printf("4. Exit\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);

            // Process user choice
            switch (choice) {
                case 1:
                    checkAccountDetails(conn, user_id);
                    break;
                case 2:
                    depositMoney(conn, user_id);
                    break;
                case 3:
                    withdrawMoney(conn, user_id);
                    break;
                case 4:
                    printf("Exiting logged-in menu.\n");
                    break;
                default:
                    printf("Invalid choice. Please enter a number between 1 and 4.\n");
                    break;
            }
        } while (choice != 4);
    } else {
        printf("Login failed. Invalid User ID or PIN.\n");
    }

    mysql_free_result(result);
}


void checkAccountDetails(MYSQL *conn, int user_id) {
    char query[256];
    sprintf(query, "SELECT * FROM account WHERE user_id = %d", user_id);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Check Account Details query failed: %s\n", mysql_error(conn));
        return;
    }

    MYSQL_RES *result = mysql_store_result(conn);
    MYSQL_ROW row = mysql_fetch_row(result);

    if (row) {
        printf("\nAccount Details:\n");
        printf("Account ID: %s, User ID: %s, Balance: %s, PIN: %s\n", row[0], row[1], row[2], row[3]);
    } else {
        printf("Account details not found for the user.\n");
    }

    mysql_free_result(result);
}

void depositMoney(MYSQL *conn, int user_id) {
    double amount;

    printf("Enter the amount to deposit: ");
    scanf("%lf", &amount);

    if (amount <= 0) {
        printf("Invalid deposit amount.\n");
        return;
    }

    // Update the account balance
    char query[256];
    sprintf(query, "UPDATE account SET balance = balance + %.2lf WHERE user_id = %d", amount, user_id);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Deposit Money query failed: %s\n", mysql_error(conn));
        return;
    }

    printf("Deposit successful. Updated balance: %.2lf\n", checkAccountBalance(conn, user_id));
}

void withdrawMoney(MYSQL *conn, int user_id) {
    double amount;

    printf("Enter the amount to withdraw: ");
    scanf("%lf", &amount);

    if (amount <= 0) {
        printf("Invalid withdrawal amount.\n");
        return;
    }

    // Check if there is sufficient balance
    double currentBalance = checkAccountBalance(conn, user_id);

    if (amount > currentBalance) {
        printf("Insufficient funds. Cannot withdraw more than the current balance.\n");
        return;
    }

    // Update the account balance
    char query[256];
    sprintf(query, "UPDATE account SET balance = balance - %.2lf WHERE user_id = %d", amount, user_id);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Withdraw Money query failed: %s\n", mysql_error(conn));
        return;
    }

    printf("Withdrawal successful. Updated balance: %.2lf\n", checkAccountBalance(conn, user_id));
}

double checkAccountBalance(MYSQL *conn, int user_id) {
    char query[256];
    sprintf(query, "SELECT balance FROM account WHERE user_id = %d", user_id);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Check Account Balance query failed: %s\n", mysql_error(conn));
        return -1.0;
    }

    MYSQL_RES *result = mysql_store_result(conn);
    MYSQL_ROW row = mysql_fetch_row(result);

    double balance = -1.0;

    if (row) {
        balance = atof(row[0]);
    }

    mysql_free_result(result);

    return balance;
}
